#!/usr/bin/bash

docker exec anismk-nginx-server certbot renew